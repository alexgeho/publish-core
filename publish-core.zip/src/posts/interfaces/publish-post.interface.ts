export interface PublishPost {
  title: string;
  excerpt: string;
  content: string;
  date: string;
}